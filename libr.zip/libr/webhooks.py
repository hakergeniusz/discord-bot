"""Allows to send message from a webhook and to delete a webhook."""
import requests

def discord_webhook(url: str, message: str, avatar_url: str = None, name: str = None):
    """Sends a message to a Discord webhook."""
    content = {
        'content': message,
        'avatar_url': avatar_url,
        'username': name
    }
    response = requests.post(url, json=content)
    return response.status_code

def webhook_deleter(url: str):
    """Deletes a webhook."""
    response = requests.delete(url)
    return response.status_code